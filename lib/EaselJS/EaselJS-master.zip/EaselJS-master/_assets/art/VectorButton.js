(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// symbols:
(lib.highlight2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#29B473","rgba(41,180,115,0)"],[0,1],0,20.3,0,-20.3).s().p("A1PDLQgIAAgGgDQgFgCAAgEIAAmDQAAgDAFgDQAGgDAIAAMAqfAAAQAIAAAGADQAFADAAADIAAGDQAAAEgFACQgGADgIAAg");
	this.shape.setTransform(138,20.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,276,40.7);


(lib.btnUp = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(241,241,242,0.2)").s().p("A3MAUQAAgYAVgSQATgSAdAAMAsaAAAQAkAAAWAbIgfAAQgMgFgPAAMgsaAAAQgdAAgTASQgUAQgBAZg");
	this.shape.setTransform(149.4,4.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#003021").s().p("AAIBgIgNg5IAAA5IhYAAIAAi/IBVAAIAQA6IAAg6IBWAAIAAC/g");
	this.shape_1.setTransform(258.2,52.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#003021").s().p("AgKBiQgyAAgXgYQgXgZAAgxQAAgyAXgYQAXgXAyAAIAVAAQAyAAAXAXQAXAYAAAyQAAAwgXAaQgXAYgyAAgAgEgLQgCACAAADIAAAeQAAAEACACQACACACAAQADAAACgCQACgCAAgEIAAgeQAAgDgCgCQgDgDgCAAQgCAAgCADg");
	this.shape_2.setTransform(237.4,52.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_3.setTransform(217.4,52.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_4.setTransform(199.3,52.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#003021").s().p("AgCBhQgyAAgXgVQgXgWAAgtIAAhpIBbAAIAABzQAAAEACACQACACADAAQADAAACgCQACgCAAgEIAAhzIBcAAIAABpQAAAtgXAWQgWAVgzAAg");
	this.shape_5.setTransform(179.7,52.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#003021").s().p("AhhBgIAAi/IBkAAQAvAAAXAOQAVAPAAAeQAAALgDAJQgCAJgEAEIgCADQAKAEADASQACAHAAAKQAAAbgQAPQgRAPgfAAgAgCAdIAWAAQAEAAABgCQADgEAAgCQAAgDgDgDQgBgCgEAAIgWAAgAgCAAIAOAAIAAgNQAAgEgCgCQgCgCgEAAIgGAAg");
	this.shape_6.setTransform(159.3,52.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#003021").s().p("AAJBgQgBgdgGgVIgCgHIgEAAIAAA5IhgAAIAAi/IBkAAQAxAAAXARQAYAQgBAoQABAdgUAOQARAeAIAtgAgEARIAGAAQADAAACgCQACgCAAgEIAAgPQAAgEgCgCQgDgCgCAAIgGAAg");
	this.shape_7.setTransform(131.2,52.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#003021").s().p("AgKBiQgyAAgXgYQgXgZAAgxQAAgyAXgYQAXgXAyAAIAVAAQAyAAAXAXQAXAYAAAyQAAAxgXAZQgXAYgyAAgAgEgLQgCACAAADIAAAeQAAAEACACQACACACAAQADAAACgCQADgCAAgEIAAgeQAAgDgDgCQgCgDgDAAQgCAAgCADg");
	this.shape_8.setTransform(109.7,52.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_9.setTransform(89.8,52.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#003021").s().p("Ag+BJQgagZAAgwQAAgyAagYQAagXAxAAQATAAAWACQAPACAMADIAIADIAABVQgagEgvAAIAAANIAUABQATAAAbgCIAHAAIAABTQgbAJgyAAQgvAAgbgZg");
	this.shape_10.setTransform(71.2,52.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#003021").s().p("AhOBgIAAi/ICaAAIAABRIg8AAIAAAMIA8AAIAAAPIg8AAIAAALIA/AAIAABIg");
	this.shape_11.setTransform(53.3,52.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#003021").s().p("Ag/BgIgki/IBfAAIAFBvIAGAAIAGhvIBXAAIgjC/g");
	this.shape_12.setTransform(34.7,52.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(35,31,32,0.6)").s().p("A2RG+QgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIIAAAhIgrAAQgBgHgGgFQgFgFgIAAMgrOAAAQgIAAgFAGQgGAFAAAIIAAMNQAAANANAEIAAAmg");
	this.shape_13.setTransform(149.7,49.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.2)").s().p("A2QAHQgJAAgHgCQgGgCAAgDQAAgCAGgCQAHgCAJAAMAshAAAQAJAAAGACQAHACAAACQAAADgHACQgGACgJAAg");
	this.shape_14.setTransform(149.4,96.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.2)").s().p("A1YAUQgJAAgGgGQgGgGAAgIQAAgHAGgGQAGgGAJAAMAqxAAAQAIAAAHAGQAGAGAAAHQAAAIgGAGQgHAGgIAAg");
	this.shape_15.setTransform(149.5,52.1,0.991,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.2)").s().p("A1YAUQgJAAgGgGQgGgGAAgIQAAgHAGgGQAGgGAJAAMAqxAAAQAIAAAHAGQAGAGAAAHQAAAIgGAGQgHAGgIAAg");
	this.shape_16.setTransform(149.5,12.3,0.991,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#048E69").s().p("A1PCJQgTAAAAgGIAAkFQAAgDAFgBQAGgCAIAAMAqfAAAQAIAAAGACQAFABAAADIAAEFQAAAGgTAAg");
	this.shape_17.setTransform(149.5,68.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#29B473","rgba(41,180,115,0)"],[0,1],0,20.3,0,-20.3).s().p("A1PDLQgIAAgGgDQgFgCAAgEIAAmDQAAgDAFgDQAGgDAIAAMAqfAAAQAIAAAGADQAFADAAADIAAGDQAAAEgFACQgGADgIAAg");
	this.shape_18.setTransform(149.7,34);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#00563D","#007154","#008A68"],[0,0.557,1],0,0,0,0,0,99.9).s().p("A06GTQgHAAgGgFQgFgGgBgHIAAsBQABgHAFgFQAGgGAHAAMAp1AAAQAHAAAGAGQAFAFABAHIAAMBQgBAHgFAGQgGAFgHAAg");
	this.shape_19.setTransform(149.7,49.3,1.016,0.968);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#009970").s().p("A1nGZQgIABgFgGQgGgFAAgIIAAsNQAAgHAGgGQAFgFAIgBMArPAAAQAIABAFAFQAGAGAAAHIAAMNQAAAIgGAFQgFAGgIgBg");
	this.shape_20.setTransform(149.7,49.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#102B1E").p("AV1mTQAGAFAAAIIAAMNQAAAIgGAFQgFAGgIAAMgrPAAAQgIAAgFgGQgGgFAAgIIAAsNQAAgIAGgFQAFgGAIAAMArPAAAQAIAAAFAGg");
	this.shape_21.setTransform(149.7,49.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#232323").p("AWmmpIAANTQAAAJgGAFQgFAGgJAAMgsjAAAQgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIg");
	this.shape_22.setTransform(149.7,49.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#333333").p("AXYmpIAANTQAAAdgUAVQgVAUgdAAMgsjAAAQgdAAgVgUQgUgVAAgdIAAtTQAAgdAUgVQAVgUAdAAMAsjAAAQAdAAAVAUQAUAVAAAdg");
	this.shape_23.setTransform(149.7,49.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#404041","#58595B","#404041"],[0,0.263,0.988],0,44.7,0,-44.6).s().p("A2RG+QgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIIAANTQAAAJgGAFQgFAGgJAAgA16GHQAAAIAGAFQAFAFAIAAMArOAAAQAJAAAFgFQAGgFAAgIIAAsNQAAgIgGgFQAGAFAAAIIAAMNQAAAIgGAFQgFAFgJAAMgrOAAAQgIAAgFgFQgGgFAAgIIAAsNQAAgIAGgFQAFgGAIAAMArOAAAQAIAAAGAGQgGgGgIAAMgrOAAAQgIAAgFAGQgGAFAAAIIAAMNg");
	this.shape_24.setTransform(149.7,49.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#58595B","#58595B","#D0D2D3","#58595B","#C3C5C7","#58595B"],[0,0.012,0.173,0.506,0.769,0.929],0,49.7,0,-49.6).s().p("A2RHwQgdAAgVgUQgUgVAAgdIAAtTQAAgdAUgVQAVgUAdAAMAsjAAAQAdAAAVAUQAUAVAAAdIAANTQAAAdgUAVQgVAUgdAAgA2fm3QgGAGAAAIIAANTQAAAJAGAFQAGAGAIAAMAsjAAAQAJAAAFgGQAGgFAAgJIAAtTQAAgIgGgGQgFgGgJAAMgsjAAAQgIAAgGAGg");
	this.shape_25.setTransform(149.7,49.7);

	this.addChild(this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-1,301.4,101.4);


(lib.btnOver = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(241,241,242,0.2)").s().p("A3MAUQAAgYAVgSQATgSAdAAMAsaAAAQAkAAAWAbIgfAAQgMgFgPAAMgsaAAAQgdAAgTASQgUAQgBAZg");
	this.shape.setTransform(149.4,4.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#003021").s().p("AAIBgIgNg5IAAA5IhYAAIAAi/IBVAAIAQA6IAAg6IBWAAIAAC/g");
	this.shape_1.setTransform(258.2,52.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#003021").s().p("AgKBiQgyAAgXgYQgXgZAAgxQAAgyAXgYQAXgXAyAAIAVAAQAyAAAXAXQAXAYAAAyQAAAwgXAaQgXAYgyAAgAgEgLQgCACAAADIAAAeQAAAEACACQACACACAAQADAAACgCQACgCAAgEIAAgeQAAgDgCgCQgDgDgCAAQgCAAgCADg");
	this.shape_2.setTransform(237.4,52.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_3.setTransform(217.4,52.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_4.setTransform(199.3,52.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#003021").s().p("AgCBhQgyAAgXgVQgXgWAAgtIAAhpIBbAAIAABzQAAAEACACQACACADAAQADAAACgCQACgCAAgEIAAhzIBcAAIAABpQAAAtgXAWQgWAVgzAAg");
	this.shape_5.setTransform(179.7,52.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#003021").s().p("AhhBgIAAi/IBkAAQAvAAAXAOQAVAPAAAeQAAALgDAJQgCAJgEAEIgCADQAKAEADASQACAHAAAKQAAAbgQAPQgRAPgfAAgAgCAdIAWAAQAEAAABgCQADgEAAgCQAAgDgDgDQgBgCgEAAIgWAAgAgCAAIAOAAIAAgNQAAgEgCgCQgCgCgEAAIgGAAg");
	this.shape_6.setTransform(159.3,52.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#003021").s().p("AAJBgQgBgdgGgVIgCgHIgEAAIAAA5IhgAAIAAi/IBkAAQAxAAAXARQAYAQgBAoQABAdgUAOQARAeAIAtgAgEARIAGAAQADAAACgCQACgCAAgEIAAgPQAAgEgCgCQgDgCgCAAIgGAAg");
	this.shape_7.setTransform(131.2,52.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#003021").s().p("AgKBiQgyAAgXgYQgXgZAAgxQAAgyAXgYQAXgXAyAAIAVAAQAyAAAXAXQAXAYAAAyQAAAxgXAZQgXAYgyAAgAgEgLQgCACAAADIAAAeQAAAEACACQACACACAAQADAAACgCQADgCAAgEIAAgeQAAgDgDgCQgCgDgDAAQgCAAgCADg");
	this.shape_8.setTransform(109.7,52.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_9.setTransform(89.8,52.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#003021").s().p("Ag+BJQgagZAAgwQAAgyAagYQAagXAxAAQATAAAWACQAPACAMADIAIADIAABVQgagEgvAAIAAANIAUABQATAAAbgCIAHAAIAABTQgbAJgyAAQgvAAgbgZg");
	this.shape_10.setTransform(71.2,52.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#003021").s().p("AhOBgIAAi/ICaAAIAABRIg8AAIAAAMIA8AAIAAAPIg8AAIAAALIA/AAIAABIg");
	this.shape_11.setTransform(53.3,52.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#003021").s().p("Ag/BgIgki/IBfAAIAFBvIAGAAIAGhvIBXAAIgjC/g");
	this.shape_12.setTransform(34.7,52.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(35,31,32,0.6)").s().p("A2RG+QgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIIAAAhIgrAAQgBgHgGgFQgFgFgIAAMgrOAAAQgIAAgFAGQgGAFAAAIIAAMNQAAANANAEIAAAmg");
	this.shape_13.setTransform(149.7,49.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.2)").s().p("A2QAHQgJAAgHgCQgGgCAAgDQAAgCAGgCQAHgCAJAAMAshAAAQAJAAAGACQAHACAAACQAAADgHACQgGACgJAAg");
	this.shape_14.setTransform(149.4,96.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.2)").s().p("A1YAUQgJAAgGgGQgGgGAAgIQAAgHAGgGQAGgGAJAAMAqxAAAQAIAAAHAGQAGAGAAAHQAAAIgGAGQgHAGgIAAg");
	this.shape_15.setTransform(149.5,84.2,0.991,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.2)").s().p("A1YAUQgJAAgGgGQgGgGAAgIQAAgHAGgGQAGgGAJAAMAqxAAAQAIAAAHAGQAGAGAAAHQAAAIgGAGQgHAGgIAAg");
	this.shape_16.setTransform(149.6,12.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2BC47C").s().p("A1PCJQgTAAAAgGIAAkFQAAgDAFgBQAGgCAIAAMAqfAAAQAIAAAGACQAFABAAADIAAEFQAAAGgTAAg");
	this.shape_17.setTransform(149.5,68.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#29B473","rgba(41,180,115,0)"],[0,1],0,20.3,0,-20.3).s().p("A1PDLQgIAAgGgDQgFgCAAgEIAAmDQAAgDAFgDQAGgDAIAAMAqfAAAQAIAAAGADQAFADAAADIAAGDQAAAEgFACQgGADgIAAg");
	this.shape_18.setTransform(149.7,34);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2ED085").s().p("A06GTQgHAAgGgFQgFgGgBgHIAAsBQABgHAFgFQAGgGAHAAMAp1AAAQAHAAAGAGQAFAFABAHIAAMBQgBAHgFAGQgGAFgHAAg");
	this.shape_19.setTransform(149.7,49.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2ED085").s().p("A1nGZQgIABgFgGQgGgFAAgIIAAsNQAAgHAGgGQAFgFAIgBMArPAAAQAIABAFAFQAGAGAAAHIAAMNQAAAIgGAFQgFAGgIgBg");
	this.shape_20.setTransform(149.7,49.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#102B1E").p("AV1mTQAGAFAAAIIAAMNQAAAIgGAFQgFAGgIAAMgrPAAAQgIAAgFgGQgGgFAAgIIAAsNQAAgIAGgFQAFgGAIAAMArPAAAQAIAAAFAGg");
	this.shape_21.setTransform(149.7,49.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#232323").p("AWmmpIAANTQAAAJgGAFQgFAGgJAAMgsjAAAQgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIg");
	this.shape_22.setTransform(149.7,49.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#333333").p("AXYmpIAANTQAAAdgUAVQgVAUgdAAMgsjAAAQgdAAgVgUQgUgVAAgdIAAtTQAAgdAUgVQAVgUAdAAMAsjAAAQAdAAAVAUQAUAVAAAdg");
	this.shape_23.setTransform(149.7,49.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#404041","#58595B","#404041"],[0,0.263,0.988],0,44.7,0,-44.6).s().p("A2RG+QgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIIAANTQAAAJgGAFQgFAGgJAAgA16GHQAAAIAGAFQAFAFAIAAMArOAAAQAJAAAFgFQAGgFAAgIIAAsNQAAgIgGgFQAGAFAAAIIAAMNQAAAIgGAFQgFAFgJAAMgrOAAAQgIAAgFgFQgGgFAAgIIAAsNQAAgIAGgFQAFgGAIAAMArOAAAQAIAAAGAGQgGgGgIAAMgrOAAAQgIAAgFAGQgGAFAAAIIAAMNg");
	this.shape_24.setTransform(149.7,49.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#58595B","#58595B","#D0D2D3","#58595B","#C3C5C7","#58595B"],[0,0.012,0.173,0.506,0.769,0.929],0,49.7,0,-49.6).s().p("A2RHwQgdAAgVgUQgUgVAAgdIAAtTQAAgdAUgVQAVgUAdAAMAsjAAAQAdAAAVAUQAUAVAAAdIAANTQAAAdgUAVQgVAUgdAAgA2fm3QgGAGAAAIIAANTQAAAJAGAFQAGAGAIAAMAsjAAAQAJAAAFgGQAGgFAAgJIAAtTQAAgIgGgGQgFgGgJAAMgsjAAAQgIAAgGAGg");
	this.shape_25.setTransform(149.7,49.7);

	this.addChild(this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-1,301.4,101.4);


(lib.btnDown = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(241,241,242,0.2)").s().p("A3MAUQAAgYAVgSQATgSAdAAMAsaAAAQAkAAAWAbIgfAAQgMgFgPAAMgsaAAAQgdAAgTASQgUAQgBAZg");
	this.shape.setTransform(149.4,4.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#003021").s().p("AAIBgIgNg5IAAA5IhYAAIAAi/IBVAAIAQA6IAAg6IBWAAIAAC/g");
	this.shape_1.setTransform(258.2,52.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#003021").s().p("AgKBiQgyAAgXgYQgXgZAAgxQAAgyAXgYQAXgXAyAAIAVAAQAyAAAXAXQAXAYAAAyQAAAwgXAaQgXAYgyAAgAgEgLQgCACAAADIAAAeQAAAEACACQACACACAAQADAAACgCQACgCAAgEIAAgeQAAgDgCgCQgDgDgCAAQgCAAgCADg");
	this.shape_2.setTransform(237.4,52.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_3.setTransform(217.4,52.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_4.setTransform(199.3,52.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#003021").s().p("AgCBhQgyAAgXgVQgXgWAAgtIAAhpIBbAAIAABzQAAAEACACQACACADAAQADAAACgCQACgCAAgEIAAhzIBcAAIAABpQAAAtgXAWQgWAVgzAAg");
	this.shape_5.setTransform(179.7,52.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#003021").s().p("AhhBgIAAi/IBkAAQAvAAAXAOQAVAPAAAeQAAALgDAJQgCAJgEAEIgCADQAKAEADASQACAHAAAKQAAAbgQAPQgRAPgfAAgAgCAdIAWAAQAEAAABgCQADgEAAgCQAAgDgDgDQgBgCgEAAIgWAAgAgCAAIAOAAIAAgNQAAgEgCgCQgCgCgEAAIgGAAg");
	this.shape_6.setTransform(159.3,52.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#003021").s().p("AAJBgQgBgdgGgVIgCgHIgEAAIAAA5IhgAAIAAi/IBkAAQAxAAAXARQAYAQgBAoQABAdgUAOQARAeAIAtgAgEARIAGAAQADAAACgCQACgCAAgEIAAgPQAAgEgCgCQgDgCgCAAIgGAAg");
	this.shape_7.setTransform(131.2,52.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#003021").s().p("AgKBiQgyAAgXgYQgXgZAAgxQAAgyAXgYQAXgXAyAAIAVAAQAyAAAXAXQAXAYAAAyQAAAxgXAZQgXAYgyAAgAgEgLQgCACAAADIAAAeQAAAEACACQACACACAAQADAAACgCQADgCAAgEIAAgeQAAgDgDgCQgCgDgDAAQgCAAgCADg");
	this.shape_8.setTransform(109.7,52.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#003021").s().p("AgzBgIAAhuIghAAIAAhRICpAAIAABRIgiAAIAABug");
	this.shape_9.setTransform(89.8,52.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#003021").s().p("Ag+BJQgagZAAgwQAAgyAagYQAagXAxAAQATAAAWACQAPACAMADIAIADIAABVQgagEgvAAIAAANIAUABQATAAAbgCIAHAAIAABTQgbAJgyAAQgvAAgbgZg");
	this.shape_10.setTransform(71.2,52.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#003021").s().p("AhOBgIAAi/ICaAAIAABRIg8AAIAAAMIA8AAIAAAPIg8AAIAAALIA/AAIAABIg");
	this.shape_11.setTransform(53.3,52.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#003021").s().p("Ag/BgIgki/IBfAAIAFBvIAGAAIAGhvIBXAAIgjC/g");
	this.shape_12.setTransform(34.7,52.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(35,31,32,0.6)").s().p("A2RG+QgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIIAAAhIgrAAQgBgHgGgFQgFgFgIAAMgrOAAAQgIAAgFAGQgGAFAAAIIAAMNQAAANANAEIAAAmg");
	this.shape_13.setTransform(149.7,49.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.2)").s().p("A2QAHQgJAAgHgCQgGgCAAgDQAAgCAGgCQAHgCAJAAMAshAAAQAJAAAGACQAHACAAACQAAADgHACQgGACgJAAg");
	this.shape_14.setTransform(149.4,96.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.2)").s().p("A1YAUQgJAAgGgGQgGgGAAgIQAAgHAGgGQAGgGAJAAMAqxAAAQAIAAAHAGQAGAGAAAHQAAAIgGAGQgHAGgIAAg");
	this.shape_15.setTransform(149.5,86.3,0.991,1);

	this.instance = new lib.highlight2();
	this.instance.setTransform(149.7,34,1,1.017,0,0,0,138,20.3);
	this.instance.alpha = 0.238;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.098)").s().p("A1YAUQgJAAgGgGQgGgGAAgIQAAgHAGgGQAGgGAJAAMAqxAAAQAIAAAHAGQAGAGAAAHQAAAIgGAGQgHAGgIAAg");
	this.shape_16.setTransform(149.5,12.3,0.991,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#01AC55").s().p("A1PCJQgTAAAAgGIAAkFQAAgDAFgBQAGgCAIAAMAqfAAAQAIAAAGACQAFABAAADIAAEFQAAAGgTAAg");
	this.shape_17.setTransform(149.5,68.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00AD54").s().p("A06GTQgHAAgGgFQgFgGgBgHIAAsBQABgHAFgFQAGgGAHAAMAp1AAAQAHAAAGAGQAFAFABAHIAAMBQgBAHgFAGQgGAFgHAAg");
	this.shape_18.setTransform(149.7,49.3,1.016,0.968);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#009251").s().p("A1nGZQgIABgFgGQgGgFAAgIIAAsNQAAgHAGgGQAFgFAIgBMArPAAAQAIABAFAFQAGAGAAAHIAAMNQAAAIgGAFQgFAGgIgBg");
	this.shape_19.setTransform(149.7,49.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#102B1E").p("AV1mTQAGAFAAAIIAAMNQAAAIgGAFQgFAGgIAAMgrPAAAQgIAAgFgGQgGgFAAgIIAAsNQAAgIAGgFQAFgGAIAAMArPAAAQAIAAAFAGg");
	this.shape_20.setTransform(149.7,49.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#232323").p("AWmmpIAANTQAAAJgGAFQgFAGgJAAMgsjAAAQgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIg");
	this.shape_21.setTransform(149.7,49.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#333333").p("AXYmpIAANTQAAAdgUAVQgVAUgdAAMgsjAAAQgdAAgVgUQgUgVAAgdIAAtTQAAgdAUgVQAVgUAdAAMAsjAAAQAdAAAVAUQAUAVAAAdg");
	this.shape_22.setTransform(149.7,49.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#404041","#58595B","#404041"],[0,0.263,0.988],0,44.7,0,-44.6).s().p("A2RG+QgIAAgGgGQgGgFAAgJIAAtTQAAgIAGgGQAGgGAIAAMAsjAAAQAJAAAFAGQAGAGAAAIIAANTQAAAJgGAFQgFAGgJAAgA16GHQAAAIAGAFQAFAFAIAAMArOAAAQAJAAAFgFQAGgFAAgIIAAsNQAAgIgGgFQAGAFAAAIIAAMNQAAAIgGAFQgFAFgJAAMgrOAAAQgIAAgFgFQgGgFAAgIIAAsNQAAgIAGgFQAFgGAIAAMArOAAAQAIAAAGAGQgGgGgIAAMgrOAAAQgIAAgFAGQgGAFAAAIIAAMNg");
	this.shape_23.setTransform(149.7,49.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#58595B","#58595B","#D0D2D3","#58595B","#C3C5C7","#58595B"],[0,0.012,0.173,0.506,0.769,0.929],0,49.7,0,-49.6).s().p("A2RHwQgdAAgVgUQgUgVAAgdIAAtTQAAgdAUgVQAVgUAdAAMAsjAAAQAdAAAVAUQAUAVAAAdIAANTQAAAdgUAVQgVAUgdAAgA2fm3QgGAGAAAIIAANTQAAAJAGAFQAGAGAIAAMAsjAAAQAJAAAFgGQAGgFAAgJIAAtTQAAgIgGgGQgFgGgJAAMgsjAAAQgIAAgGAGg");
	this.shape_24.setTransform(149.7,49.7);

	this.addChild(this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.instance,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-1,301.4,101.4);


(lib.VectorButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2});

	// Layer 1
	this.instance = new lib.btnUp();
	this.instance.setTransform(149.7,49.6,1,1,0,0,0,149.7,49.6);

	this.instance_1 = new lib.btnOver();
	this.instance_1.setTransform(149.7,49.6,1,1,0,0,0,149.7,49.6);

	this.instance_2 = new lib.btnDown();
	this.instance_2.setTransform(149.7,49.6,1,1,0,0,0,149.7,49.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,300.4,100.4);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;